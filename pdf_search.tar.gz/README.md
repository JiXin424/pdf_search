# PDF智能问答系统

一个基于React + FastAPI的PDF上传、预览和智能问答系统。

## 项目结构

```
pdf_search/
├── frontend/          # React前端
│   ├── src/           # 源代码
│   ├── public/        # 静态资源
│   ├── package.json   # 前端依赖
│   └── vite.config.js # Vite配置
├── backend/           # FastAPI后端
│   ├── app/           # 应用代码
│   │   ├── routes/    # 路由
│   │   ├── models/    # 数据模型
│   │   ├── services/  # 业务逻辑
│   │   └── utils/     # 工具函数
│   ├── uploads/       # 上传文件目录
│   ├── main.py        # 主应用文件
│   └── requirements.txt # 后端依赖
└── README.md          # 项目说明
```

## 功能特性

### 前端功能
- 📄 PDF文件上传（拖拽/点击）
- 📜 滚动式PDF预览
- 🔍 矩形放大镜（实时跟随）
- ✂️ 智能区域截图（可拖拽调整）
- 📱 页面跳转输入框
- 💬 截图问答界面

### 后端功能
- 🚀 FastAPI异步框架
- 📤 文件上传处理
- 🔗 CORS跨域支持
- 📋 API文档自动生成
- 🔍 健康检查接口

## 快速开始

### 前端启动

```bash
cd frontend
npm install
npm run dev
```

前端将运行在 `http://localhost:3000`

### 后端启动

```bash
cd backend
pip install -r requirements.txt
python main.py
```

后端将运行在 `http://localhost:8000`

API文档：`http://localhost:8000/docs`

## API接口

- `POST /api/ask` - 提交问题和截图
- `POST /api/upload` - 上传PDF文件
- `GET /api/health` - 健康检查

## 技术栈

### 前端
- React 18
- Vite
- react-pdf
- html2canvas

### 后端
- FastAPI
- Uvicorn
- Pydantic
- aiofiles

## 开发说明

- 前端环境变量：`frontend/.env`
- 后端环境变量：`backend/.env`
- 上传文件存储：`backend/uploads/`